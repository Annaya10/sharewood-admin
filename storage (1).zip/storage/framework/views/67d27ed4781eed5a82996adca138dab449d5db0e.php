
<?php $__env->startSection('page_meta'); ?>
<meta name="description" content=<?php echo e(!empty($site_settings) ? $site_settings->site_meta_desc : ''); ?>">
<meta name="keywords" content="<?php echo e(!empty($site_settings) ? $site_settings->site_meta_keyword : ''); ?>">
<meta name="author" content="<?php echo e(!empty($site_settings->site_name) ? $site_settings->site_name : 'Login'); ?>">
<title>Admin - <?php echo e(!empty($site_settings->site_name) ? $site_settings->site_name : 'Login'); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_content'); ?>

<div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
  data-sidebar-position="fixed" data-header-position="fixed">
  <div
    class="position-relative overflow-hidden text-bg-light min-vh-100 d-flex align-items-center justify-content-center">
    <div class="d-flex align-items-center justify-content-center w-100">
      <div class="row justify-content-center w-100">
        <div class="col-md-8 col-lg-6 col-xxl-3">
          <div class="card mb-0">
            <div class="card-body">
              <a href="<?php echo e(url('admin/login')); ?>" class="text-nowrap logo-img text-center d-block py-3 w-100">
                <img class="for-light"
                  src="<?php echo e(!empty($site_settings) ? get_site_image_src('images', $site_settings->site_logo) : get_site_image_src('images', '')); ?>" alt="<?php echo e(!empty($site_settings) ? $site_settings->site_name : 'Login'); ?>">
              </a>
              <p class="text-center"><?php echo e(!empty($site_settings) ? $site_settings->site_name : 'Login'); ?></p>
              <form class="theme-form" action="<?php echo e(url('admin/login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo showMessage(); ?>

                <div class="mb-3">
                  <label for="exampleInputEmail1" class="form-label">Username</label>
                  <input type="text" class="form-control" name="site_username" placeholder=""
                    value="<?php echo e(old('site_username')); ?>" />
                  <?php $__errorArgs = ['site_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4">
                  <label for="" class="form-label">Password</label>
                  <input type="password" class="form-control" name="site_password">
                  <?php $__errorArgs = ['site_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="invalid-feedback"><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <a href="<?php echo e(route('admin.forgot_password')); ?>">Forgot Password?</a>


                <br>
                <br>

                <button class="btn btn-primary w-100 py-8 fs-4 mb-4 rounded-2" type="submit">Sign in</button>

              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sharewood update admin\sharewood-admin\resources\views/admin/login.blade.php ENDPATH**/ ?>