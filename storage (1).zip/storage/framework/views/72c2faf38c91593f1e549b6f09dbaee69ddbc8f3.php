
<?php $__env->startSection('page_meta'); ?>
<meta name="description" content=<?php echo e(!empty($site_settings) ? $site_settings->site_meta_desc : ''); ?>">
<meta name="keywords" content="<?php echo e(!empty($site_settings) ? $site_settings->site_meta_keyword : ''); ?>">
<meta name="author" content="<?php echo e(!empty($site_settings->site_name) ? $site_settings->site_name : 'Login'); ?>">
<title>Admin - <?php echo e($site_settings->site_name); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_content'); ?>
<?php echo breadcrumb('Site Settings'); ?>

<form class="form theme-form" method="post" action="<?php echo e(url('admin/settings')); ?>"
  enctype="multipart/form-data" id="saveForm">
  <?php echo csrf_field(); ?>
  <div class="card">
    <div class="card-body">
      <div class="row">
        <div class="col-lg-4 d-flex align-items-stretch">
          <div class="card w-100 border position-relative overflow-hidden">
            <div class="card-body p-4">
              <h4 class="card-title">Change Logo</h4>
              <p class="card-subtitle mb-4">Change your Site Logo</p>
              <div class="text-center">
                <div class="file_choose_icon">
                  <img src="<?php echo e(get_site_image_src('images', $site_settings->site_logo)); ?>" alt="matdash-img" class="img-fluid ">
                </div>
                <p class="mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                <input class="form-control uploadFile" name="site_logo" type="file"
                  data-bs-original-title="" title="">
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 d-flex align-items-stretch">
          <div class="card w-100 border position-relative overflow-hidden">
            <div class="card-body p-4">
              <h4 class="card-title">Change Fav Icon</h4>
              <p class="card-subtitle mb-4">Change your Site FavIcon</p>
              <div class="text-center">
                <div class="file_choose_icon">
                  <img src="<?php echo e(get_site_image_src('images', $site_settings->site_icon)); ?>" alt="matdash-img" class="img-fluid ">
                </div>
                <p class="mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                <input class="form-control uploadFile" name="site_icon" type="file"
                  data-bs-original-title="" title="">
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 d-flex align-items-stretch">
          <div class="card w-100 border position-relative overflow-hidden">
            <div class="card-body p-4">
              <h4 class="card-title">Change Thumb</h4>
              <p class="card-subtitle mb-4">Change your Site Thumb</p>
              <div class="text-center">
                <div class="file_choose_icon">
                  <img src="<?php echo e(get_site_image_src('images', $site_settings->site_thumb)); ?>" alt="matdash-img" class="img-fluid ">
                </div>
                <p class="mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                <input class="form-control uploadFile" name="site_thumb" type="file"
                  data-bs-original-title="" title="">
              </div>
            </div>
          </div>
        </div>
        <div class="col-12">
          <div class="card w-100 border position-relative overflow-hidden">
            <div class="card-body p-4">
              <h4 class="card-title">Personal Details</h4>
              <p class="card-subtitle mb-4">To change your Website detail , edit and save from here</p>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label for="site_domain" class="form-label">Site Domain</label>
                    <input class="form-control" id="site_domain" type="text" name="site_domain"
                      placeholder="www.example.come" value="<?php echo e($site_settings->site_domain); ?>">
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label for="site_name" class="form-label">Site Name</label>
                    <input class="form-control" id="site_name" type="text" name="site_name"
                      placeholder="" value="<?php echo e($site_settings->site_name); ?>">
                  </div>
                </div>

                <div class="col-lg-6">
                  <div class="mb-3">
                    <label for="site_email" class="form-label">Site Email</label>
                    <input class="form-control" id="site_email" type="text" name="site_email"
                      placeholder="" value="<?php echo e($site_settings->site_email); ?>">
                  </div>
                </div>

                <div class="col-lg-6">
                  <div class="mb-3">
                    <label for="site_admin_email" class="form-label">Site Admin Email</label>
                    <input class="form-control" id="site_admin_email" type="text" name="site_admin_email"
                      placeholder="" value="<?php echo e($site_settings->site_admin_email); ?>">
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="mb-3">
                    <label for="site_phone" class="form-label">Site Phone</label>
                    <input class="form-control" id="site_phone" type="text" name="site_phone"
                      placeholder="" value="<?php echo e($site_settings->site_phone); ?>">
                  </div>
                </div>

                <div class="col-lg-6">
                  <div class="mb-3">
                    <label for="site_noreply_email" class="form-label">Site No-Reply Email</label>
                    <input class="form-control" id="site_noreply_email" type="text" name="site_noreply_email"
                      placeholder="" value="<?php echo e($site_settings->site_noreply_email); ?>">
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="mb-3">
                    <label for="site_address" class="form-label">Site Address</label>
                    <textarea class="form-control" id="site_address" rows="3" name="site_address"><?php echo e($site_settings->site_address); ?></textarea>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="mb-3">
                    <label for="site_about" class="form-label">Site About</label>
                    <textarea class="form-control" id="site_about" rows="3" name="site_about"><?php echo e($site_settings->site_about); ?></textarea>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="mb-3">
                    <label for="site_copyright" class="form-label">Site Copyright</label>
                    <textarea class="form-control" id="site_copyright" rows="3" name="site_copyright"><?php echo e($site_settings->site_copyright); ?></textarea>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class="col-12">
          <div class="card w-100 border position-relative overflow-hidden">
            <div class="card-body p-4">
              <h4 class="card-title">Meta Details</h4>
              <p class="card-subtitle mb-4">To change your meta detail , edit and save from here</p>
              <div class="row">
                <div class="col-lg-12">
                  <div class="mb-3">
                    <label for="site_domain" class="form-label">Site Meta Description</label>
                    <textarea class="form-control" id="site_meta_desc" rows="3" name="site_meta_desc"><?php echo e($site_settings->site_meta_desc); ?></textarea>
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="mb-3">
                    <label for="site_copyright" class="form-label">Site Meta Keywords</label>
                    <textarea class="form-control" id="site_meta_keyword" rows="3" name="site_meta_keyword"><?php echo e($site_settings->site_meta_keyword); ?></textarea>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>


        <div class="col-12">
          <div class="card w-100 border position-relative overflow-hidden">
            <div class="card-body p-4">
              <h4 class="card-title">Site Social Links</h4>
              <p class="card-subtitle mb-4">To change your meta detail , edit and save from here</p>
              <div class="row">
                <div class="col-lg-6">
                  <div class="mb-3">
                    <div class="">
                      <label class="form-check-label" for="color-success"> Instagram</label>
                      <input class="form-control" id="site_instagram" type="text"
                        name="site_instagram" placeholder="www.instagram.com/account_name"
                        value="<?php echo e($site_settings->site_instagram); ?>">
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="mb-3">
                    <div class="">
                      <label class="form-check-label" for="color-success"> Facebook</label>
                      <input class="form-control" id="site_facebook" type="text"
                        name="site_facebook" placeholder="www.instagram.com/account_name"
                        value="<?php echo e($site_settings->site_facebook); ?>">
                    </div>
                  </div>
                </div>
                <div class="col-lg-6">
                  <div class="mb-3">
                    <div class="">
                      <label class="form-check-label" for="color-success"> Linkedin</label>
                      <input class="form-control" id="site_linkedin" type="text"
                        name="site_linkedin" placeholder="www.instagram.com/account_name"
                        value="<?php echo e($site_settings->site_linkedin); ?>">
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="d-flex align-items-center justify-content-end mt-4 gap-6">
                    <button class="btn btn-primary" type="submit">Update Site Settings</button>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sharewood update admin\sharewood-admin\resources\views/admin/site_settings.blade.php ENDPATH**/ ?>