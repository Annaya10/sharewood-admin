<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php echo $__env->make('admin/includes/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('page_meta'); ?>

</head>

<body>
    <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6"  data-sidebartype="full"
    data-sidebar-position="fixed" data-header-position="fixed">
        <?php echo $__env->make('admin/includes/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
        <div class="body-wrapper">
            <?php echo $__env->make('admin/includes/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="body-wrapper-inner">
                <div class="container-fluid">
                    <?php echo showMessage(); ?>

                    <?php echo $__env->yieldContent('page_content'); ?>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('admin/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\sharewood-main\resources\views/layouts/adminlayout.blade.php ENDPATH**/ ?>