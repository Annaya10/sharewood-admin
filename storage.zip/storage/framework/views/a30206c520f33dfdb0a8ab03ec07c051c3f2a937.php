<header class="ease">
    <div class="contain">
        <div class="logo">
            <a href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="">
            </a>
        </div>
        <div class="toggle"><span></span></div>
        <nav class="ease" id="nav">
            <ul>
                <li class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/')); ?>">Home</a>
                </li>

                <li class="drop <?php echo e(request()->is('company') ? 'active' : ''); ?>">
                    <a href="javascript:void(0)">Company</a>
                    <ul class="sub">
                        <li><a href="<?php echo e(url('about')); ?>">Company Overview</a></li>
                        <li><a href="<?php echo e(url('about#vision')); ?>">Vision</a></li>
                        <li><a href="<?php echo e(url('about#locations')); ?>">Global Locations</a></li>
                        <li><a href="<?php echo e(url('about#manufacturing')); ?>">Manufacturing</a></li>
                    </ul>
                </li>

                <li class="<?php echo e(request()->is('products') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('products')); ?>">Products & Capabilities</a>
                </li>

                <li class="drop <?php echo e(request()->is('careers') ? 'active' : ''); ?>">
                    <a href="javascript:void(0)">Careers</a>
                    <ul class="sub">
                        <li><a href="<?php echo e(url('careers')); ?>">Jobs</a></li>
                        <li><a href="<?php echo e(url('careers#team')); ?>">Team Tecvox</a></li>
                    </ul>
                </li>

                <li class="<?php echo e(request()->is('supplier') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('supplier')); ?>">Supplier Portal</a>
                </li>

                <li class="btn_blk">
                    <a href="<?php echo e(url('contact')); ?>" class="site_btn">Contact Us</a>
                </li>
            </ul>
        </nav>
        <div class="clearfix"></div>
    </div>
</header>

<div class="pBar hidden">
    <span id="myBar" style="width:0%"></span>
</div><?php /**PATH C:\xampp\htdocs\sharewood update admin\sharewood-admin\resources\views/includes/header.blade.php ENDPATH**/ ?>