

<!-- latest jquery-->

<?php echo $__env->make('admin/includes/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\sharewood-main\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>