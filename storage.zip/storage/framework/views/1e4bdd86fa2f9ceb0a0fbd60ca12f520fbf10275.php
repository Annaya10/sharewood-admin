
<?php $__env->startSection('page_meta'); ?>
    <meta name="description" content=<?php echo e(!empty($site_settings) ? $site_settings->site_meta_desc : ''); ?>">
    <meta name="keywords" content="<?php echo e(!empty($site_settings) ? $site_settings->site_meta_keyword : ''); ?>">
    <meta name="author" content="<?php echo e(!empty($site_settings->site_name) ? $site_settings->site_name : 'Login'); ?>">
    <title>Admin - <?php echo e($site_settings->site_name); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_content'); ?>
<?php echo breadcrumb('Subscribers'); ?>

    <div class="card">
      <div class="card-body">
          <div class="row">
              <div class="table-responsive">  
                  <table id="zero_config" class="table table-striped table-bordered text-nowrap align-middle">
                        <thead>
                            <tr>
                                <th>Sr#</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(!empty($rows)): ?>
                                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="sorting_1"><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($row->email); ?></td>
                                        <td><?php echo getReadStatus($row->status); ?></td>
                                        <td class="action">
                                            <a href="<?php echo e(url('admin/subscribers/delete/' . $row->id)); ?>" class="text-dark delete ms-2" onclick="return confirm('Are you sure?');">
                                                <i class="ti ti-trash fs-5"></i>
                                              </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr class="odd">
                                    <td colspan="6">No record(s) found!</td>
                                </tr>
                            <?php endif; ?>



                        </tbody>
                    </table>
                </div>
            </div>
        </div>
      </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sharewood update admin\sharewood-admin\resources\views/admin/subscribers.blade.php ENDPATH**/ ?>