<meta name="description" content=<?php echo e(!empty($site_settings) ? $site_settings->site_meta_desc : ''); ?>">
<meta name="keywords" content="<?php echo e(!empty($site_settings) ? $site_settings->site_meta_keyword : ''); ?>">
<meta name="author" content="pixelstrap">
<link rel="icon"
    href="<?php echo e(!empty($site_settings) ? get_site_image_src('images', $site_settings->site_icon) : get_site_image_src('images', '')); ?>"
    type="image/x-icon">
<link rel="shortcut icon"
    href="<?php echo e(!empty($site_settings) ? get_site_image_src('images', $site_settings->site_icon) : get_site_image_src('images', '')); ?>"
    type="image/x-icon">
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Rubik:400,400i,500,500i,700,700i&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900&amp;display=swap"
    rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('admin/datatables/datatables.min.css')); ?>" />
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

<link rel="stylesheet" href="<?php echo e(asset('admin/css/owl.carousel.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('admin/css/styles.min.css')); ?>" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

<style>
    #dragger {
        position: absolute;
        width: 0;
        height: 0;
        border-left: 10px solid transparent;
        border-right: 10px solid transparent;
        border-top: 20px solid orange;
        border-top-right-radius: 25px;
        border-top-left-radius: 25px;
        cursor: pointer;

    }
</style><?php /**PATH C:\xampp\htdocs\sharewood update admin\sharewood-admin\resources\views/admin/includes/master.blade.php ENDPATH**/ ?>