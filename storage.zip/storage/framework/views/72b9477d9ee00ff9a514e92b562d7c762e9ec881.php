
<?php $__env->startSection('page_meta'); ?>
<meta name="description" content=<?php echo e(!empty($site_settings) ? $site_settings->site_meta_desc : ''); ?>">
<meta name="keywords" content="<?php echo e(!empty($site_settings) ? $site_settings->site_meta_keyword : ''); ?>">
<meta name="author" content="<?php echo e(!empty($site_settings->site_name) ? $site_settings->site_name : 'Login'); ?>">
<title>Admin - <?php echo e($site_settings->site_name); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_content'); ?>
<?php if(request()->segment(3) == 'view'): ?>
<?php echo breadcrumb('View Message'); ?>

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="card border shadow-none">
                    <div class="card-body p-4">
                        <h4 class="card-title mb-3">Message Details</h4>
                        <div class="d-flex align-items-center justify-content-between pb-7">
                        </div>
                        <div class="d-flex align-items-center justify-content-between py-3 border-top">
                            <div>
                                <h5 class="fs-4 fw-semibold mb-0">Name</h5>
                            </div>
                            <p class="mb-0"><?php echo e($row->name); ?></p>
                        </div>
                        <div class="d-flex align-items-center justify-content-between py-3 border-top">
                            <div>
                                <h5 class="fs-4 fw-semibold mb-0">Email</h5>
                            </div>
                            <p class="mb-0"><?php echo e($row->email); ?></p>
                        </div>
                        <div class="d-flex align-items-center justify-content-between py-3 border-top">
                            <div>
                                <h5 class="fs-4 fw-semibold mb-0">Phone</h5>
                            </div>
                            <p class="mb-0"><?php echo e($row->phone); ?></p>
                        </div>
                        <div class="d-flex align-items-center justify-content-between py-3 border-top">
                            <div>
                                <h5 class="fs-4 fw-semibold mb-0">Message</h5>
                            </div>
                            <p class="mb-0"><?php echo e($row->message); ?></p>
                        </div>
                        <div class="d-flex align-items-center justify-content-between py-3 border-top">
                            <div>
                                <h5 class="fs-4 fw-semibold mb-0">Hear About</h5>
                            </div>
                            <p class="mb-0"><?php echo e($row->hear_about); ?></p>
                        </div>
                        <!-- <div class="d-flex align-items-center justify-content-between py-3 border-top">
                                  <div>
                                      <h5 class="fs-4 fw-semibold mb-0">Services</h5>
                                  </div>
                                  <p class="mb-0"><?php echo e($row->services); ?></p>
                              </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<?php echo breadcrumb('Contact Messages'); ?>

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="table-responsive">
                <table id="zero_config" class="table table-striped table-bordered text-nowrap align-middle">
                    <thead>
                        <!-- start row -->
                        <tr>
                            <th>Sr#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        <!-- end row -->
                    </thead>
                    <tbody>
                        <?php if(!empty($rows)): ?>
                        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="sorting_1"><?php echo e($key + 1); ?></td>
                            <td><?php echo e($row->name); ?></td>
                            <td><?php echo e($row->email); ?></td>
                            <td><?php echo e($row->phone); ?></td>
                            <td><?php echo getReadStatus($row->status); ?></td>
                            <td>
                                <div class="dropdown dropstart">
                                    <a href="javascript:void(0)" class="text-muted" id="dropdownMenuButton"
                                        data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="ti ti-dots-vertical fs-6"></i>
                                    </a>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <li>
                                            <a class="dropdown-item d-flex align-items-center gap-3"
                                                href="<?php echo e(url('admin/contact/view/' . $row->id)); ?>">
                                                <i class="fs-4 ti ti-eye"></i>View
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item d-flex align-items-center gap-3"
                                                href="<?php echo e(url('admin/contact/delete/' . $row->id)); ?>"
                                                onclick="return confirm('Are you sure?');">
                                                <i class="fs-4 ti ti-trash"></i>Delete
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="4">No record(s) found!</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sharewood update admin\sharewood-admin\resources\views/admin/contact.blade.php ENDPATH**/ ?>