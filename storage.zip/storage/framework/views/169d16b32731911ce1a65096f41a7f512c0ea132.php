
<?php $__env->startSection('page_meta'); ?>
    <meta name="description" content=<?php echo e(!empty($site_settings) ? $site_settings->site_meta_desc : ''); ?>">
    <meta name="keywords" content="<?php echo e(!empty($site_settings) ? $site_settings->site_meta_keyword : ''); ?>">
    <meta name="author" content="<?php echo e(!empty($site_settings->site_name) ? $site_settings->site_name : 'Login'); ?>">
    <title>Admin - <?php echo e($site_settings->site_name); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_content'); ?>
<?php echo breadcrumb('Home Page'); ?>

<form class="form theme-form" method="post" action="" enctype="multipart/form-data"
id="saveForm">
<?php echo csrf_field(); ?>
<div class="card">
    <div class="card-body">
        <div class="row">
           
            <div class="row">
                <div class="col">
                    <div>
                        <label class="form-label" for="page_title">Page Title</label>
                        <input class="form-control" id="page_title" type="text" name="page_title"
                                        placeholder="" value="<?php echo e($sitecontent['page_title']); ?>">
                    </div>
                </div>
            </div>
             <div class="row">
                 <div class="col">
                     <div>
                         <label class="form-label" for="meta_title">Meta Title</label>
                         <input class="form-control" id="meta_title" type="text" name="meta_title"
                                        placeholder="" value="<?php echo e($sitecontent['meta_title']); ?>">
                     </div>
                 </div>
             </div>
            <div class="row">
                <div class="col">
                    <div>
                        <label class="form-label" for="site_meta_desc">Meta Description</label>
                        <textarea class="form-control" id="meta_description" rows="3" name="meta_description"><?php echo e($sitecontent['meta_description']); ?></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                 <div class="col">
                    <div>
                        <label class="form-label" for="meta_keywords">Meta Keywords</label>
                        <textarea class="form-control" id="meta_keywords" rows="3" name="meta_keywords"><?php echo e($sitecontent['meta_keywords']); ?></textarea>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>
<div class="card">

    <div class="card-header">
        <h5>Banner</h5>
    </div>

    <div class="card-body">

        <div class="row">
            <div class="col">
                <div class="card w-100 border position-relative overflow-hidden">
                    <div class="card-body p-4">
                      <div class="text-center">
                       <div class="file_choose_icon">
                          <img src="<?php echo e(get_site_image_src('images', $sitecontent['image1'])); ?>" alt="matdash-img" class="img-fluid " >
                       </div>
                        <p class="mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                        <input class="form-control uploadFile" name="image1" type="file"
                            data-bs-original-title="" title="">
                      </div>
                    </div>
                  </div>
            </div>

            <div class="col-md-8">
                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="banner_heading1">Heading</label>
                            <input class="form-control" id="banner_heading1" type="text"
                                name="banner_heading1" placeholder=""
                                value="<?php echo e(!empty($sitecontent['banner_heading1']) ? $sitecontent['banner_heading1'] : ""); ?>">
                        </div>
                    </div>
                </div>
                <!-- <div class="row">
                    <div class="col">
                        <div class="mb-3">
                        <label class="form-label" for="banner_typing">Enter Words (comma-separated):</label>
                        <textarea id="banner_typing" name="banner_typing" rows="4" class="editor">
                            <?php echo e($sitecontent['banner_typing'] ?? ''); ?>

                        </textarea>
                        </div>
                    </div>
                </div> -->
                <!-- <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="banner_text">Text</label>
                            <textarea id="banner_text" name="banner_text" rows="4" class="editor"><?php echo e($sitecontent['banner_text']); ?></textarea>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <?php for($i = 1; $i < 3; $i++): ?>
                    <div class="col">
                        <div class="mb-4">
                            <label class="form-label" for="banner_link_text_<?php echo e($i); ?>">Link Text <?php echo e($i); ?></label>
                            <input class="form-control" id="banner_link_text_<?php echo e($i); ?>" type="text"
                                name="banner_link_text_<?php echo e($i); ?>" placeholder=""
                                value="<?php echo e(!empty($sitecontent['banner_link_text_' . $i]) ? $sitecontent['banner_link_text_' . $i] : ''); ?>">
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-4">
                            <label class="form-label" for="banner_link_url_<?php echo e($i); ?>">Link URL <?php echo e($i); ?></label>
                            <select name="banner_link_url_<?php echo e($i); ?>" class="form-control" required>
                                <?php $__currentLoopData = $all_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"
                                        <?php echo e(!empty($sitecontent['banner_link_url_' . $i]) && $sitecontent['banner_link_url_' . $i] == $key ? 'selected' : ''); ?>>
                                        <?php echo e($page); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>                 -->
                
            </div>

        </div>
    </div>


</div>

<div class="card">

    <div class="card-header">
        <h5>Section 1</h5>
    </div>

  <div class="card-body">
      <div class="row">
            <div class="col">
                <div class="card w-100 border position-relative overflow-hidden">
                    <div class="card-body p-4">
                      <div class="text-center">
                       <div class="file_choose_icon">
                          <img src="<?php echo e(get_site_image_src('images', $sitecontent['image2'])); ?>" alt="matdash-img" class="img-fluid " >
                       </div>
                        <p class="mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                        <input class="form-control uploadFile" name="image2" type="file"
                            data-bs-original-title="" title="">
                      </div>
                    </div>
                  </div>
            </div>

            <div class="col-md-8">
                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="banner_heading1">Heading</label>
                            <input class="form-control" id="section1_heading" type="text"
                                name="section1_heading" placeholder=""
                                value="<?php echo e(!empty($sitecontent['section1_heading']) ? $sitecontent['section1_heading'] : ""); ?>">
                        </div>
                    </div>
                </div>
            
                 <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="section1__text">Text</label>
                            <textarea id="banner_text" name="section1__text" rows="4" class="editor"><?php echo e($sitecontent['section1__text']); ?></textarea>
                        </div>
                    </div>
                </div>
                
                <!-- <div class="row">
                    <?php for($i = 1; $i < 3; $i++): ?>
                    <div class="col">
                        <div class="mb-4">
                            <label class="form-label" for="banner_link_text_<?php echo e($i); ?>">Link Text <?php echo e($i); ?></label>
                            <input class="form-control" id="banner_link_text_<?php echo e($i); ?>" type="text"
                                name="banner_link_text_<?php echo e($i); ?>" placeholder=""
                                value="<?php echo e(!empty($sitecontent['banner_link_text_' . $i]) ? $sitecontent['banner_link_text_' . $i] : ''); ?>">
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-4">
                            <label class="form-label" for="banner_link_url_<?php echo e($i); ?>">Link URL <?php echo e($i); ?></label>
                            <select name="banner_link_url_<?php echo e($i); ?>" class="form-control" required>
                                <?php $__currentLoopData = $all_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"
                                        <?php echo e(!empty($sitecontent['banner_link_url_' . $i]) && $sitecontent['banner_link_url_' . $i] == $key ? 'selected' : ''); ?>>
                                        <?php echo e($page); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>               -->
                
            </div>

        </div>


  </div>

    <!-- <div class="card-body">

        <div class="row">

        <div class="col-md-12">
        <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="banner_heading">Heading</label>
                            <input class="form-control" id="banner_heading" type="text"
                                name="banner_heading" placeholder=""
                                value="<?php echo e(!empty($sitecontent['banner_heading']) ? $sitecontent['banner_heading'] : ""); ?>">
                        </div>
        </div>

        <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="banner_text">Text</label>
                            <textarea id="banner_text" name="banner_text" rows="4" class="editor"><?php echo e($sitecontent['banner_text']); ?></textarea>
                        </div>
        </div>
        </div>

        
            <?php $how_block_count = 0; ?>
            <?php for($i = 2; $i <= 4; $i++): ?>
                <?php $how_block_count = $how_block_count + 1; ?>
                <div class="col-4">
                    <div class="card">

                        <div class="card-header">
                            <h5>Block <?php echo e($how_block_count); ?></h5>
                        </div>
                    
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <div class="card w-100 border position-relative overflow-hidden">
                                        <div class="card-body p-4">
                                        <div class="text-center">
                                        <div class="file_choose_icon">
                                            <img src="<?php echo e(get_site_image_src('images', !empty($sitecontent['image' . $i]) ? $sitecontent['image' . $i] : '')); ?>" alt="matdash-img" class="img-fluid " >
                                        </div>
                                            <p class="mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                                            <input class="form-control uploadFile" name="image<?php echo e($i); ?>" type="file"
                                                data-bs-original-title="" title="">
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            
                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="mb-3">
                                        <label class="form-label"
                                            for="sec1_heading<?php echo e($i); ?>">Heading
                                            <?php echo e($how_block_count); ?></label>
                                        <input class="form-control"
                                            id="sec1_heading<?php echo e($i); ?>" type="text"
                                            name="sec1_heading<?php echo e($i); ?>" placeholder=""
                                            value="<?php echo e(!empty($sitecontent['sec1_heading' . $i]) ? $sitecontent['sec1_heading' . $i] : ""); ?>">
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="mb-2">
                                        <label class="form-label"
                                            for="sec1_text<?php echo e($i); ?>">Text
                                            <?php echo e($how_block_count); ?></label>
                                        <textarea id="sec1_text<?php echo e($i); ?>" name="sec1_text<?php echo e($i); ?>" rows="4"
                                            class="form-control"><?php echo e(!empty($sitecontent['sec1_text' . $i]) ? $sitecontent['sec1_text' . $i] : ""); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>
        </div>
    </div> -->


</div>
<div class="card">

    <div class="card-header">
        <h5>Section 2</h5>
    </div>

    <div class="card-body">
      <div class="row">
            <div class="col">
                <div class="card w-100 border position-relative overflow-hidden">
                    <div class="card-body p-4">
                      <div class="text-center">
                       <div class="file_choose_icon">
                          <img src="<?php echo e(get_site_image_src('images', $sitecontent['image3'])); ?>" alt="matdash-img" class="img-fluid " >
                       </div>
                        <p class="mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                        <input class="form-control uploadFile" name="image3" type="file"
                            data-bs-original-title="" title="">
                      </div>
                    </div>
                  </div>
            </div>

            <div class="col-md-8">
                <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="banner_heading1">Heading</label>
                            <input class="form-control" id="section2_heading" type="text"
                                name="section2_heading" placeholder=""
                                value="<?php echo e(!empty($sitecontent['section2_heading']) ? $sitecontent['section2_heading'] : ""); ?>">
                        </div>
                    </div>
                </div>
            
                 <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="section2__text">Text</label>
                            <textarea id="banner_text" name="section2__text" rows="4" class="editor"><?php echo e(!empty($sitecontent['section2__text']) ? $sitecontent['section2__text'] : ""); ?></textarea>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <?php for($i = 1; $i < 2; $i++): ?>
                    <div class="col">
                        <div class="mb-4">
                            <label class="form-label" for="banner_link_text_<?php echo e($i); ?>">Link Text <?php echo e($i); ?></label>
                            <input class="form-control" id="banner_link_text_<?php echo e($i); ?>" type="text"
                                name="banner_link_text_<?php echo e($i); ?>" placeholder=""
                                value="<?php echo e(!empty($sitecontent['banner_link_text_' . $i]) ? $sitecontent['banner_link_text_' . $i] : ''); ?>">
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-4">
                            <label class="form-label" for="banner_link_url_<?php echo e($i); ?>">Link URL <?php echo e($i); ?></label>
                            <select name="banner_link_url_<?php echo e($i); ?>" class="form-control" required>
                                <?php $__currentLoopData = $all_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"
                                        <?php echo e(!empty($sitecontent['banner_link_url_' . $i]) && $sitecontent['banner_link_url_' . $i] == $key ? 'selected' : ''); ?>>
                                        <?php echo e($page); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>              
                
            </div>

        </div>


  </div>

  


</div>
<div class="card">

    <div class="card-header">
        <h5>Section 3</h5>
    </div>

    <div class="card-body">

        <div class="row">
          

            <div class="col-md-12">
                <div class="row">
                
                  

                    <div class="row">
               
            </div>



                    <?php $section3_block_count = 0; ?>
            <?php for($i = 2; $i <= 6; $i++): ?>
                <?php $section3_block_count = $section3_block_count + 1; ?>
                <div class="col-4">
                    <div class="card">

                        <div class="card-header">
                            <h5>Count <?php echo e($section3_block_count); ?></h5>
                        </div>
                    
                        <div class="card-body">
                            
                            <div class="row">
                                <div class="col">
                                    <div class="mb-3">
                                        <label class="form-label"
                                            for="sec3_heading<?php echo e($i); ?>">Heading
                                            <?php echo e($section3_block_count); ?></label>
                                        <input class="form-control"
                                            id="sec3_heading<?php echo e($i); ?>" type="text"
                                            name="sec3_heading<?php echo e($i); ?>" placeholder=""
                                            value="<?php echo e(!empty($sitecontent['sec3_heading' . $i]) ? $sitecontent['sec3_heading' . $i] : ""); ?>">
                                    </div>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="mb-2">
                                        <label class="form-label"
                                            for="sec3_text<?php echo e($i); ?>">Text
                                            <?php echo e($section3_block_count); ?></label>

                                            <input class="form-control"
                                            id="sec3_text<?php echo e($i); ?>" type="text"
                                            name="sec3_text<?php echo e($i); ?>" placeholder=""
                                            value="<?php echo e(!empty($sitecontent['sec3_text' . $i]) ? $sitecontent['sec3_text' . $i] : ""); ?>">
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>


                
                </div>
            </div>

        </div>
    </div>


</div>

<div class="card">

    <div class="card-header">
        <h5>Section 4</h5>
    </div>

    <div class="card-body">

        <div class="row">
          

            <div class="col-md-12">
                <div class="row">
              
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label" for="section4_heading">Heading</label>
                            <input class="form-control" id="section4_heading" type="text"
                                name="section4_heading" placeholder=""
                                value="<?php echo e(!empty($sitecontent['section4_heading']) ? $sitecontent['section4_heading'] : ""); ?>">
                        </div>
                    </div>

                   
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label" for="section4_text">Text</label>
                            <textarea id="section4_text" name="section4_text" rows="4" class=" editor"><?php echo e(!empty($sitecontent['section4_text']) ? $sitecontent['section4_text'] : ""); ?></textarea>
                        </div>
                    </div>

                    <div class="row">
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="section4_link_text">Link Text</label>
                            <input class="form-control" id="section4_link_text" type="text"
                                name="section4_link_text" placeholder=""
                                value="<?php echo e(!empty($sitecontent['section4_link_text']) ? $sitecontent['section4_link_text'] : ""); ?>">
                        </div>
                    </div>
                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="section4_link_url">Link URL</label>
                            <select name="section4_link_url" class="form-control" required>
                                <?php $__currentLoopData = $all_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"
                                        <?php echo e(!empty($sitecontent['section4_link_url']) && $sitecontent['section4_link_url'] == $key ? 'selected' : ''); ?>>
                                        <?php echo e($page); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    </div>



                    


                
                </div>
            </div>

        </div>
    </div>


</div>

<div class="card">

    <div class="card-header">
        <h5>Section 5</h5>
    </div>

    <div class="card-body">

        <div class="row">
            

            <div class="col-md-12">
                <div class="row">
                   
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label" for="section5_heading">Heading</label>
                            <input class="form-control" id="section5_heading" type="text"
                                name="section5_heading" placeholder=""
                                value="<?php echo e(!empty($sitecontent['section5_heading']) ? $sitecontent['section5_heading'] : ""); ?>">
                        </div>
                    </div>

                    
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label" for="section5_text">Text</label>
                            <textarea id="section5_text" name="section5_text" rows="4" class=" editor"><?php echo e(!empty($sitecontent['section5_text']) ? $sitecontent['section5_text'] : ""); ?></textarea>
                        </div>
                    </div>
                    
                </div>
              
            </div>

        </div>
    </div>


</div>

<div class="card">

    <div class="card-header">
        <h5>Testimonials Section</h5>
    </div>

    <div class="card-body">
      <div class="row">
            <div class="col-md-5">
                <div class="card w-100 border position-relative overflow-hidden">
                    <div class="card-body p-4">
                      <div class="text-center">
                       <div class="file_choose_icon">
                          <img src="<?php echo e(get_site_image_src('images', $sitecontent['image7'])); ?>" alt="matdash-img" class="img-fluid " >
                       </div>
                        <p class="mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                        <input class="form-control uploadFile" name="image7" type="file"
                            data-bs-original-title="" title="">
                      </div>
                    </div>
                  </div>
            </div>

            

        </div>


  </div>

  


</div>
<div class="card">
    <div class="card-header">
        <h5>Section 6</h5>
    </div>
    <div class="card-body">
        <div class="row">
           
            <div class="col-12">
                <div class="row">
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label" for="sec6_heading">Heading</label>
                            <input class="form-control" id="sec6_heading" type="text"
                                name="sec6_heading" placeholder=""
                                value="<?php echo e(!empty($sitecontent['sec6_heading']) ? $sitecontent['sec6_heading'] : ""); ?>">
                        </div>
                    </div>

                    <div class="col">
                        <div class="mb-3">
                            <label class="form-label" for="sec6_text">Text</label>
                            <textarea id="sec6_text" name="sec6_text" rows="4" class="editor"><?php echo e(!empty($sitecontent['sec6_text']) ? $sitecontent['sec6_text'] : ""); ?></textarea>
                        </div>
                    </div>
                    <div class="col-12">
                    <div class="row">
                <div class="col">
                <div class="card w-100 border position-relative overflow-hidden">
                    <div class="card-body p-4">
                      <div class="text-center">
                       <div class="file_choose_icon">
                          <img src="<?php echo e(get_site_image_src('images', $sitecontent['image5'])); ?>" alt="matdash-img" class="img-fluid " >
                       </div>
                        <p class="mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                        <input class="form-control uploadFile" name="image5" type="file"
                            data-bs-original-title="" title="">
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col">
                <div class="card w-100 border position-relative overflow-hidden">
                    <div class="card-body p-4">
                      <div class="text-center">
                       <div class="file_choose_icon">
                          <img src="<?php echo e(get_site_image_src('images', $sitecontent['image6'])); ?>" alt="matdash-img" class="img-fluid " >
                       </div>
                        <p class="mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                        <input class="form-control uploadFile" name="image6" type="file"
                            data-bs-original-title="" title="">
                      </div>
                    </div>
                  </div>
                </div>
                    </div>
                </div>
                
            </div>
        </div>
    
    </div>
</div>


<div class="card">

    <div class="card-header">
        <h5>Section 7</h5>
    </div>

    <div class="card-body">

        <div class="row">
            

            <div class="col-md-12">
                <div class="row">
                   
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label" for="section7_heading">Heading</label>
                            <input class="form-control" id="section7_heading" type="text"
                                name="section7_heading" placeholder=""
                                value="<?php echo e(!empty($sitecontent['section7_heading']) ? $sitecontent['section7_heading'] : ""); ?>">
                        </div>
                    </div>

                    
                    <div class="col-12">
                        <div class="mb-3">
                            <label class="form-label" for="section7_text">Text</label>
                            <textarea id="section7_text" name="section7_text" rows="4" class=" editor"><?php echo e(!empty($sitecontent['section7_text']) ? $sitecontent['section7_text'] : ""); ?></textarea>
                        </div>
                    </div>
                    
                </div>
              
            </div>


            <div class="row">
         

         <div class="col-12">
             <div class="d-flex align-items-center justify-content-end mt-4 gap-6">
             <button class="btn btn-primary" type="submit">Update Page</button>
             </div>
         </div>
     </div>

        </div>
    </div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sharewood update admin\sharewood-admin\resources\views/admin/website_pages/site_home.blade.php ENDPATH**/ ?>