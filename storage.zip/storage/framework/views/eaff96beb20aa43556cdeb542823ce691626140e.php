
<?php $__env->startSection('page_meta'); ?>
<meta name="description" content=<?php echo e(!empty($site_settings) ? $site_settings->site_meta_desc : ''); ?>">
<meta name="keywords" content="<?php echo e(!empty($site_settings) ? $site_settings->site_meta_keyword : ''); ?>">
<meta name="author" content="<?php echo e(!empty($site_settings->site_name) ? $site_settings->site_name : 'Login'); ?>">
<title>Admin - <?php echo e($site_settings->site_name); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_content'); ?>

<div class="row">
  <div class="col-12">
    <?php if(access(3) || access(7) || access(8) || access(9)): ?>
    <!-- <div class="card">
            <div class="card-body pb-0" data-simplebar="">
                <div class="row flex-nowrap">
                  <?php if(access(3)): ?>
                    <div class="col">
                      <div class="card primary-gradient">
                        <div class="card-body text-center px-9 pb-4">
                          <div class="d-flex align-items-center justify-content-center round-48 rounded text-bg-primary flex-shrink-0 mb-3 mx-auto display-6">
                            <iconify-icon icon="lucide:users-round"></iconify-icon>
                          </div>
                          <h6 class="fw-normal fs-3 mb-1">Total Members</h6>
                          <h4 class="mb-3 d-flex align-items-center justify-content-center gap-1">
                            <?php echo e($members); ?></h4>
                          <a href="<?php echo e(url('/admin/members')); ?>" class="btn btn-white fs-2 fw-semibold text-nowrap">View
                            Details</a>
                        </div>
                      </div>
                    </div>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div> -->
    <?php endif; ?>
    <?php if(access(5) || access(6) || access(10)): ?>
    <div class="card">
      <div class="card-body pb-0" data-simplebar="">
        <div class="row flex-nowrap">
          <?php if(access(5)): ?>
          <div class="col">
            <div class="card primary-gradient">
              <div class="card-body text-center px-9 pb-4">
                <div class="d-flex align-items-center justify-content-center round-48 rounded text-bg-success flex-shrink-0 mb-3 mx-auto display-6">
                  <iconify-icon icon="tabler:message-user"></iconify-icon>
                </div>
                <h6 class="fw-normal fs-3 mb-1">Total Contact Messages</h6>
                <h4 class="mb-3 d-flex align-items-center justify-content-center gap-1">
                  <?php echo e($contact); ?>

                </h4>
                <a href="<?php echo e(url('/admin/contact')); ?>" class="btn btn-white fs-2 fw-semibold text-nowrap">View
                  Details</a>
              </div>
            </div>
          </div>
          <?php endif; ?>
          <?php if(access(6)): ?>
          <div class="col">
            <div class="card warning-gradient">
              <div class="card-body text-center px-9 pb-4">
                <div class="d-flex align-items-center justify-content-center round-48 rounded text-bg-info flex-shrink-0 mb-3 mx-auto display-6">
                  <iconify-icon icon="jam:newsletter"></iconify-icon>
                </div>
                <h6 class="fw-normal fs-3 mb-1">Total Subscribers</h6>
                <h4 class="mb-3 d-flex align-items-center justify-content-center gap-1">
                  <?php echo e($subscribers); ?>

                </h4>
                <a href="<?php echo e(url('/admin/subscribers')); ?>" class="btn btn-white fs-2 fw-semibold text-nowrap">View
                  Details</a>
              </div>
            </div>
          </div>
          <?php endif; ?>


        </div>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sharewood update admin\sharewood-admin\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>