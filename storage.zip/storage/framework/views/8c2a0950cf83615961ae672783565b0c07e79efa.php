<?php $__env->startSection('page_meta'); ?>
<meta name="description" content=<?php echo e(!empty($site_settings) ? $site_settings->site_meta_desc : ''); ?>">
<meta name="keywords" content="<?php echo e(!empty($site_settings) ? $site_settings->site_meta_keyword : ''); ?>">
<meta name="author" content="<?php echo e(!empty($site_settings->site_name) ? $site_settings->site_name : 'Login'); ?>">
<title>Admin - <?php echo e($site_settings->site_name); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_content'); ?>
<?php if(request()->segment(3) == 'edit' || request()->segment(3) == 'add'): ?>
<?php echo breadcrumb('Add/Update Products & Capabilities'); ?>

<form class="form theme-form" method="post" action="" enctype="multipart/form-data"
    id="saveForm">
    <?php echo csrf_field(); ?>
    <div class="card">
        <div class="card-body">
            <div class="row">

                <div class="col-lg-6 d-flex align-items-stretch">
                    <div class="card w-100 border position-relative overflow-hidden">
                        <div class="card-body p-4">
                            <h4 class="card-title">Change Image</h4>
                            <div class="text-center">
                                <div class="file_choose_icon">
                                    <img src="<?php echo e(get_site_image_src('products', !empty($row) ? $row->image : '')); ?>" alt="matdash-img" class="img-fluid" width="120" height="120">
                                </div>
                                <input class="form-control uploadFile" name="image" type="file"
                                    data-bs-original-title="" title="">
                                <p class="mb-0">Allowed JPG, GIF or PNG. Max size of 800K</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 d-flex align-items-stretch">
                    <div class="card w-100 border position-relative overflow-hidden">
                        <div class="card-body p-4">
                            <h4 class="card-title">Games</h4>
                            <div class="mb-3">
                                <label for="title" class="form-label">Title</label>
                                <input type="text" class="form-control" name="title" value="<?php echo e(!empty($row->title) ? $row->title : ""); ?>">
                            </div>


                            <div class="mb-3">
                                <div class="form-check form-switch py-2">
                                    <input class="form-check-input success" type="checkbox" id="color-success" <?php echo e(!empty($row) ? ($row->status == 1 ? 'checked' : '') : ''); ?> name="status" />
                                    <label class="form-check-label" for="color-success"> <?php echo e(!empty($row) ? ($row->status == 0 ? 'InActive' : 'Active') : 'Status'); ?></label>
                                </div>
                            </div>

                            <div class="mb-3">
                                <div class="form-check form-switch py-2">
                                    <input class="form-check-input success" type="checkbox" id="color-success2" <?php echo e(!empty($row) ? ($row->is_featured == 1 ? 'checked' : '') : ''); ?> name="featured" />
                                    <label class="form-check-label" for="color-success2"> <?php echo e(!empty($row) ? ($row->is_featured == 0 ? 'InActive' : 'Active') : 'Featured'); ?></label>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
                <div class="col-lg-12 d-flex align-items-stretch">
                    <div class="card w-100 border position-relative overflow-hidden">
                        <div class="card-body p-4">
                            <h4 class="card-title">Details Block</h4>
                            <div class="mb-3">
                                <label for="detail" class="form-label">Text</label>
                                <textarea class="editor" name="detail"><?php echo e(!empty($row) ? $row->detail : ''); ?></textarea>
                            </div>

                            <!-- <div class="row">
                                Left Column: Feature 1 and Block 1
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="heading_1" class="form-label">Features 1</label>
                                        <input type="text" class="form-control" name="heading_1"
                                            value="<?php echo e(!empty($row->heading_1) ? $row->heading_1 : ""); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="block_1" class="form-label">Block 1</label>
                                        <textarea class="editor" name="block_1"><?php echo e(!empty($row) ? $row->block_1 : ''); ?></textarea>
                                    </div>
                                </div>

                                Right Column: Feature 2 and Block 2
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="heading_2" class="form-label">Features 2</label>
                                        <input type="text" class="form-control" name="heading_2"
                                            value="<?php echo e(!empty($row->heading_2) ? $row->heading_2 : ""); ?>">
                                    </div>
                                    <div class="mb-3">
                                        <label for="block_2" class="form-label">Block 2</label>
                                        <textarea class="editor" name="block_2"><?php echo e(!empty($row) ? $row->block_2 : ''); ?></textarea>
                                    </div>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>

                <div class="col-lg-12 d-flex align-items-stretch">
                    <div class="card w-100 border position-relative overflow-hidden">
                        <div class="card-body p-4">
                            <h4 class="card-title">Meta Information Block</h4>
                            <div class="mb-3">
                                <label for="detail" class="form-label">Meta Title</label>
                                <input class="form-control" id="meta_title" type="text" name="meta_title"
                                    placeholder=""
                                    value="<?php echo e(!empty($row->meta_title) ? $row->meta_title : ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="detail" class="form-label">Meta Description</label>
                                <textarea class="form-control" id="meta_description" rows="3" name="meta_description"><?php echo e(!empty($row->meta_description) ? $row->meta_description : ''); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="detail" class="form-label">Meta Keywords</label>
                                <textarea class="form-control" id="meta_keywords" rows="3" name="meta_keywords"><?php echo e(!empty($row->meta_keywords) ? $row->meta_keywords : ''); ?></textarea>
                            </div>
                            <div class="col-12">
                                <div class="d-flex align-items-center justify-content-end mt-4 gap-6">
                                    <button class="btn btn-primary" type="submit">Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<?php else: ?>
<?php echo breadcrumb('Manage Games',url('admin/games/add/')); ?>

<div class="card">
    <div class="card-body">
        <div class="row">
           
            <div class="table-responsive">
                    <table id="zero_config" class="table table-striped table-bordered text-nowrap align-middle">
                        <thead>
                            <!-- start row -->
                            <tr>
                                <th>Sr#</th>
                                <th>Image</th>
                                <th>Title</th>
                                <th>Status</th>
                                <th>Featured</th>
                                <th>Action</th>
                            </tr>
                            <!-- end row -->
                        </thead>
                        <tbody>
                            <?php if(!empty($rows)): ?>
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td>
                                    <div class="d-flex align-items-center gap-6 crud_thumbnail_icon">
                                        <img src="<?php echo e(get_site_image_src('games', !empty($row->image) ? $row->image : '')); ?>" width="45" class="rounded-circle" />

                                    </div>

                                </td>
                                <td><?php echo $row->title; ?></td>
                                <td><?php echo getStatus($row->status); ?></td>
                                <td><?php echo getFeatured($row->is_featured); ?></td>
                                <td>
                                    <div class="dropdown dropstart">
                                        <a href="javascript:void(0)" class="text-muted" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                                            <i class="ti ti-dots-vertical fs-6"></i>
                                        </a>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <li>
                                                <a class="dropdown-item d-flex align-items-center gap-3" href="<?php echo e(url('admin/games/edit/' . $row->id)); ?>">
                                                    <i class="fs-4 ti ti-edit"></i>Edit
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item d-flex align-items-center gap-3" href="<?php echo e(url('admin/games/delete/' . $row->id)); ?>" onclick="return confirm('Are you sure?');">
                                                    <i class="fs-4 ti ti-trash"></i>Delete
                                                </a>
                                            </li>

                                            <li>
                                                <a class="dropdown-item d-flex align-items-center gap-3" href="<?php echo e(url('admin/games/levels/' . $row->id)); ?>" >
                                                    <i class="fs-4 ti ti-trash"></i>Add Levels
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr class="odd">
                                <td colspan="4">No record(s) found!</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sharewood-main\resources\views/admin/games/index.blade.php ENDPATH**/ ?>