<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <?php
    $page_title = empty($site_content['page_title'])
    ? ($page_title . " - " . $site_settings->site_name)
    : ($site_content['page_title'] . " - " . $site_settings->site_name);
    $meta_description = empty($site_content['meta_description'])
    ? $site_settings->site_meta_desc
    : $site_content['meta_description'];
    $meta_keywords = empty($site_content['meta_keywords'])
    ? $site_settings->site_meta_keyword
    : $site_content['meta_keywords'];
    $meta_image = empty($site_content['meta_image'])
    ? get_site_image_src("images", $site_settings->site_thumb) . '?v-' . $site_settings->site_version
    : $site_content['meta_image'];
    ?>

    <meta name="title" content="<?php echo e($page_title); ?>">
    <meta name="description" content="<?php echo e($meta_description); ?>">
    <meta name="keywords" content="<?php echo e($meta_keywords); ?>">
    <meta property="og:type" content="website">
    <!-- <meta property="og:url" content="<?php echo e(request()->url()); ?>"> -->
    <meta property="og:title" content="<?php echo e($page_title); ?>">
    <meta property="og:description" content="<?php echo e($meta_description); ?>">
    <meta property="og:site_about" content="<?php echo e($site_settings->site_about); ?>">
    <meta property="og:image" content="<?php echo e($meta_image); ?>">
    <meta property="twitter:card" content="thumbnail">
    <!-- <meta property="twitter:url" content="<?php echo e(request()->url()); ?>"> -->
    <meta property="twitter:title" content="<?php echo e($page_title); ?>">
    <meta property="twitter:description" content="<?php echo e($meta_description); ?>">
    <meta property="twitter:image" content="<?php echo e($meta_image); ?>">

    <!-- CSS Files -->
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/App.css?v=0.3')); ?>">
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/commonCss.css?v=0.2')); ?>">

    <!-- //////////////my files/////////// -->

    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/toastr.min.css')); ?>">





    <title><?php echo e($page_title); ?></title>

    <!-- Favicon -->
    <link type="image/png" rel="icon" href="<?php echo e(get_site_image_src('images', $site_settings->site_icon) . '?v-' . $site_settings->site_version); ?>">
</head>

<body id="home-page">

    <!-- Message Display -->
    
    
    

    <?php if(empty($page_404) && !empty($footer)): ?>
    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php echo $__env->make($pageView, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(empty($page_404) && !empty($footer)): ?>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php echo $__env->make('includes.commonjs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\sharewood update admin\sharewood-admin\resources\views/includes/site-master.blade.php ENDPATH**/ ?>